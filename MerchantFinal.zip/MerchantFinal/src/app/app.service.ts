import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';

import { Inventory } from './models/inventory';
import { Offers } from './models/offers';

import { Feedback } from './models/feeback';
import { Product } from './models/product';


@Injectable({
  providedIn: 'root'
})
export class AppService {
 
  
  //mailId

  mailId:string;

  private filterBy:string;
  private subject = new Subject<any>();
 
  url:string="http://localhost:8086/capstore/api/v1/"
  constructor(private _http:HttpClient) { }

  setmailId(mailId:string)
  {

    this.mailId=mailId;
   
  }

 
    getmailId()
    {
      return this.mailId;
    }

  //change Password
  comparepassword(password:String):Observable<boolean>{
   
     
    return this._http.post<boolean>(this.url+"passwordMatch/"+this.mailId,password,{})
  }
    
    changepassword(password:String):Observable<boolean>{
      return this._http.post<boolean>(this.url+"passwordChange/"+this.mailId,password,{})
  }
  

  //manageInventory
  getProductsInventory(): Observable<Inventory[]> {
    
    return this._http.get<Inventory[]>(this.url+"inventories/"+this.mailId);
  }

  deleteInventory(inventoryId: number): Observable<{}> {
    return this._http.delete(this.url +'inventories/'+ inventoryId);
  }

  editInventory(inventory: Inventory): Observable<Boolean> {
    console.log(inventory)
    console.log(this.mailId)
    return this._http.post<Boolean>(this.url+'editInventories/'+this.mailId, inventory);
  }

  addInventory(inventory: Inventory): Observable<Boolean> {
    console.log(inventory)
    console.log(this.mailId)
    return this._http.post<Boolean>(this.url+'addInventories/'+this.mailId, inventory);
  }

  addOffer(offers: Offers): Observable<Boolean> {
    return this._http.post<Boolean>(this.url+'inventories/offers', offers);
  }


  getAllOffers():Observable<Offers[]>{
    return this._http.get<Offers[]>(this.url+"getAllOffers");
  }
  getOffer(offerDescription:string):Observable<Offers>{
   return this._http.get<Offers>(this.url+"getOffer/"+offerDescription);
  }

  //mainHeader

  performFilter(filterby: string): void {
    //console.log("Service reached");
    this.subject.next({ text: filterby });
    //console.log(this.filterBy);
  }
  
  getPerformFilter():Observable<any>{
    // console.log("Service Getter");
    // console.log(this.filteredProducts);
    // return this.filteredProducts.asObservable();
  
    return this.subject.asObservable();
    
  }
  
  
  
  logout(){

   this.mailId=null;
   window.location.href="//localhost:4200";
  }

  //feedback service
  getFeedbacks():Observable<Feedback[]> {
    
    return this._http.get<Feedback[]>(this.url+"merchantFeedback/"+this.mailId);
  }

  getAverageRating(): Observable<number> {
    
    return this._http.get<number>(this.url+"averageRating/"+this.mailId);
  }

//Upload service team 3





pushFileToStorage(file: File,productId:number): Observable<HttpEvent<{}>> {
  const formdata: FormData = new FormData();
  
  formdata.append('file', file);


  const req = new HttpRequest('POST',this.url+"postMerchant/"+productId , formdata, {
    reportProgress: true,
    responseType: 'text'
  });

  return this._http.request(req);
}
pushSliderToStorage(file: File,productId:number,id:number): Observable<HttpEvent<{}>> {
  const formdata: FormData = new FormData();
  
  formdata.append('file', file);


  const req = new HttpRequest('POST', 'http://localhost:8086/capstore/api/v1/sliderMerchant/'+productId+'/'+id, formdata, {
    reportProgress: true,
    responseType: 'text'
  });

  return this._http.request(req);
}
getMerchantProducts():  Observable<Product[]> {
  return this._http.get<Product[]>('http://localhost:8086/capstore/api/v1/viewMerchantProducts/'+this.mailId);
}

getFiles(): Observable<Product[]> {
  return this._http.get<Product[]>('http://localhost:8086/capstore/api/v1/getallfiles');
}

}

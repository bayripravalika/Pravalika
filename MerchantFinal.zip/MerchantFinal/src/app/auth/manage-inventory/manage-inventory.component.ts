import { Component, OnInit } from '@angular/core';
import { Inventory } from '../../models/inventory';
import { Product } from'../../models/product'

import { Offers } from '../../models/offers';
import { AppService } from '../../app.service';
import { routerNgProbeToken } from '@angular/router/src/router_module';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-inventory',
  templateUrl: './manage-inventory.component.html',
  styleUrls: ['./manage-inventory.component.scss']
})
export class ManageInventoryComponent implements OnInit {

  products: Inventory[]=[];
  offers:Offers[]=[];
  inventory:Inventory={

    inventoryId:0,
    merchant:{
      merchantId:0,
      merchantName:"",
      merchantEmailId:"",
      merchantContact:"",
      password:"",
      merchantAddress:{
        addressId:0,
         addressLine1:"",
         addressLine2:"",
         city:"",
         state:"",
         pincode:0
       },
      isVerified:true,
  },
  productId:"",
    productName:"",
        productPrice:0,
        quantity:0,
        discountOffered:0,
    productCategory:"",
    productType:"",
     productBrand:"",
	productModel:"",
	
    productDescription:"",
   productRating:0,
   productFeedback:"",
   
    offer:"",
    status:"pending",
    inventoryType:"",
    inventoryQuantity:0,
    imageUrl:''
  };


  offer: Offers
  // ={ 
  //   promoId: 0,
  //   promoCode:'',
  //   discount:0,
  //   endDate:null
  
  //   }
    ;


  _listFilter: string;

  filteredProducts: Inventory[];

  constructor(private manageInventoryService: AppService, private router:Router) {


    this.listFilter = '';

  }

  get listFilter(): string {

    return this._listFilter;

  }
  



  set listFilter(value: string) {

    this._listFilter = value;

    this.filteredProducts = this.listFilter ? this.performFilter(this.listFilter) : this.products;

  }

  ngOnInit() {
    this.manageInventoryService.getProductsInventory().subscribe(products => {
      // if(products.indexOf[0]==null)
      // {
      //   alert("Not Found")
      // }
      
      // else
      this.products = products;
      console.log(this.products);
      this.filteredProducts=this.products;
      console.log(this.filteredProducts);
      
    });


    this.manageInventoryService.getAllOffers().subscribe(offers=>{
      this.offers=offers;
      console.log(this.offers);
      // this.getInventories();
      // this.length=this.inventories.length;
    });
    
  }

  // getProducts(): void{

  //   this.manageInventoryService.getProducts()

  //   .subscribe(products => { this.products= this.products;

  //   this.filteredProducts=this.products;});

  //   }


  dltInventory(inventoryId: number) {
    this.manageInventoryService.deleteInventory(inventoryId).subscribe(flag=>

      {
        this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
        this.router.navigate(['/auth/manageInventory']))
      }
    );
    //this.router.navigate(['/auth/abc'])
   

  }

  promoCode:string;

  editInventory(inventory:Inventory) {

    this.manageInventoryService.getOffer(this.productDescription).subscribe(offer=>{
      console.log(offer);
      this.inventory.offer=offer;
      this.manageInventoryService.editInventory(inventory).subscribe(flag=>{
        if(flag){
          //alert("edited!");
          let element:HTMLElement=document.getElementById("close1");
          element.click();
           this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
          this.router.navigate(['/auth/manageInventory']))
        }
      });
    });
    
   
   
  }

  addInventory(inventory:Inventory) {

    console.log(inventory);
    this.manageInventoryService.getOffer(this.productDescription).subscribe(offer=>{
      console.log(offer);
      this.inventory.offer=offer;
      this.manageInventoryService.addInventory(inventory).subscribe(flag=>{
        if(flag){
         // alert("added!");
          let element:HTMLElement=document.getElementById("close");
          element.click();
          this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
        this.router.navigate(['/auth/manageInventory']))
        }
      });
      console.log(inventory);
    });

   
    

  
   
  }

  addOffer(offer:Offers):void {
    console.log(offer);
    this.manageInventoryService.addOffer(offer).subscribe(flag=>{
      if(flag){
        alert("added!");
      }
    });
    this.inventory.offer=offer;
  }

  performFilter(filterBy: string): Inventory[] {

    filterBy = filterBy.toLocaleLowerCase();

    return this.products.filter((inventory: Inventory) =>

    inventory.productName.toLocaleLowerCase().indexOf(filterBy) !== -1 ||
    inventory.productCategory.toLocaleLowerCase().indexOf(filterBy) !== -1 ||
    inventory.inventoryType.toLocaleLowerCase().indexOf(filterBy) !== -1);

  }


  getInventoryObject(inventory){

    this.inventory=Object.assign({},inventory);
  }


}

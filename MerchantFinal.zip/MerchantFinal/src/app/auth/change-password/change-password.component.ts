import { Component, OnInit } from '@angular/core';


import {Md5} from 'ts-md5'; 
import { AppService } from '../../app.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {


  currentPassword:string
  newPassword:string
  confirmPassword:string
  message:string

  constructor(private service:AppService,private _router:Router) { }

  ngOnInit() {
    console.log(this.service.getmailId()+"ghjgghjg");
  }
  submit1(){
  
if(this.confirmPassword==this.newPassword){
  const md5 = new Md5();
    this.currentPassword=md5.appendStr(this.currentPassword).end().toString();
    console.log("method1:"+this.currentPassword);

  this.service.comparepassword(this.currentPassword).subscribe(flag=>{
    console.log("abc12");
    if(flag){
      const md5 = new Md5();
    this.newPassword=md5.appendStr(this.newPassword).end().toString();
    console.log(this.newPassword);
      this.service.changepassword(this.newPassword).subscribe(flag2=>{
        if(flag2){
          alert("Your password has been changed successfully")
          this._router.navigate(['/auth']);
        }
      })
    }
    else{
      alert("current password doesnt match")
    }
  })

}else{
  
  this.confirmPassword=null
  this.message="       *Passwords do not match"
 
}

  }

}

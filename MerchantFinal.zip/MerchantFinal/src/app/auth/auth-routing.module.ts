import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { ManageInventoryComponent } from './manage-inventory/manage-inventory.component';
import { ViewOrdersComponent } from './view-orders/view-orders.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { OfferComponent } from './offers/offer.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { SliderImageComponent } from './slider-image/slider-image.component';




const routes: Routes = [
  
  
  
  {
    path:'manageInventory',
    component:ManageInventoryComponent
  },
  {
    path:'viewOrders',
    component:ViewOrdersComponent
  }
  ,
  {
    path:'change-password',
    component:ChangePasswordComponent
  },

  {
    path:'offers',
    component:OfferComponent
  },
  
  {
    path:'inventory',
    component:ManageInventoryComponent
  },

  {
    path:'feedback',
    component:FeedbackComponent
  },

  {
    path:'uploadImage',
    component:UploadImageComponent
  },
  {
    path:'sliderImage',
    component:SliderImageComponent
  },


 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AuthRoutingModule {
}

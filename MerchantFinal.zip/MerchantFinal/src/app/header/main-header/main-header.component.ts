import { Component, ElementRef, OnInit } from '@angular/core';


import { Router } from '@angular/router';

import { AppService } from '../../app.service';
import { Product } from '../../models/product';

@Component({
  selector: 'app-main-header',
  templateUrl: './main-header.component.html',
  styleUrls: ['./main-header.component.scss'],
})
export class MainHeaderComponent implements OnInit {
 // inputModel: any;
  click:boolean=false;

  displayMenu = false;

  menuAnchor: any;

  
  _listFilter:string;
   //filteredProducts: IProduct[];
  products: Product[]=[]
  

  constructor(public el: ElementRef,private _service:AppService,private _router: Router) {
  }

  ngOnInit() {
    this.menuAnchor = this.el.nativeElement;
     this._service.getMerchantProducts().subscribe(products=>this.products=products);
    let x=window.location.search.substring(6);
    this._service.setmailId(x);
    console.log(x)
  }
  get listFilter() :string{
    return this._listFilter;
}
set listFilter(value:string) {
    this._listFilter=value;

    this._service.performFilter(this.listFilter);

}

changePassword()
{
  let element:HTMLElement =document.getElementById("click");
  element.click();
  this._router.navigate(['/auth/change-password'])
}
logout(){
  this._service.logout();
  //window.location.href="//localhost:4200";
}

}

import { Address } from "./address";

export class Merchant{
    merchantId:number;
    merchantName:string;
    merchantEmailId:string;
    merchantContact:string;
    merchantAddress:Address;
    password:string;
    isVerified:boolean;
}